//
//  AddOrEditJobView.swift
//  CampusHire
//
//  Created by lokesh sagi on 12/05/25.
//


import SwiftUI
import FirebaseFirestore

struct AddOrEditJobView: View {
    var jobToEdit: JobPosting? = nil
    var onSave: () -> Void

    @Environment(\.dismiss) var dismiss

    @State private var title = ""
    @State private var company = ""
    @State private var location = ""
    @State private var salary = ""
    @State private var applicationDeadline = ""
    @State private var onlineTestDate = ""
    @State private var interviewDate = ""
    @State private var description = ""
    @State private var isUrgent = false
    @State private var minGPA = ""
    @State private var eligibleBranches = ""

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Job Info")) {
                    TextField("Title", text: $title)
                    TextField("Company", text: $company)
                    TextField("Location", text: $location)
                    TextField("Salary", text: $salary)
                }

                Section(header: Text("Dates (MMM d, yyyy)")) {
                    TextField("Application Deadline", text: $applicationDeadline)
                    TextField("Online Test Date", text: $onlineTestDate)
                    TextField("Interview Date", text: $interviewDate)
                }

                Section(header: Text("Requirements")) {
                    TextField("Minimum GPA", text: $minGPA)
                        .keyboardType(.decimalPad)
                    TextField("Eligible Branches (comma-separated)", text: $eligibleBranches)
                }

                Section(header: Text("Details")) {
                    TextEditor(text: $description)
                        .frame(height: 100)
                    Toggle("Urgent", isOn: $isUrgent)
                }

                Button(jobToEdit == nil ? "Add Job" : "Update Job") {
                    saveJob()
                }
            }
            .navigationTitle(jobToEdit == nil ? "Add Job" : "Edit Job")
            .onAppear(perform: populateFields)
        }
    }

    func populateFields() {
        guard let job = jobToEdit else { return }
        title = job.title
        company = job.company ?? ""
        location = job.location ?? ""
        salary = job.salary ?? ""
        applicationDeadline = job.applicationDeadline ?? ""
        onlineTestDate = job.onlineTestDate ?? ""
        interviewDate = job.interviewDate ?? ""
        description = job.description ?? ""
        isUrgent = job.isUrgent ?? false
        minGPA = job.minGPA ?? ""
        eligibleBranches = job.eligibleBranches?.joined(separator: ", ") ?? ""
    }

    func saveJob() {
        var jobData: [String: Any] = [
            "title": title,
            "company": company,
            "location": location,
            "salary": salary,
            "applicationDeadline": applicationDeadline,
            "onlineTestDate": onlineTestDate,
            "interviewDate": interviewDate,
            "description": description,
            "isUrgent": isUrgent,
            "minGPA": minGPA,
            "eligibleBranches": eligibleBranches.components(separatedBy: ",").map { $0.trimmingCharacters(in: .whitespaces) },
            "postedDate": Timestamp(date: Date())
        ]

        let db = Firestore.firestore().collection("jobs")
        if let existingJob = jobToEdit, let docId = existingJob.id {
            db.document(docId).updateData(jobData) { _ in
                onSave()
                dismiss()
            }
        } else {
            db.addDocument(data: jobData) { _ in
                onSave()
                dismiss()
            }
        }
    }
}