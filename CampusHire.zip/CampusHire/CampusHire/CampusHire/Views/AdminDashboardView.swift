//
//  AdminDashboardView.swift
//  CampusHire
//
//  Created by lokesh sagi on 12/05/25.
//


import SwiftUI
import FirebaseFirestore

struct AdminDashboardView: View {
    @State private var jobs: [JobPosting] = []
    @State private var isLoading = true
    @State private var showAddJob = false

    var body: some View {
        NavigationStack {
            VStack {
                if isLoading {
                    ProgressView("Loading Jobs...")
                } else if jobs.isEmpty {
                    Text("No jobs found.")
                        .foregroundColor(.gray)
                } else {
                    List(jobs) { job in
                        NavigationLink(destination: AdminJobDetailView(job: job)) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(job.title)
                                    .font(.headline)
                                Text(job.company ?? "-")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                if let deadline = job.applicationDeadline {
                                    Text("Deadline: \(deadline)")
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                }
                            }
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Admin Dashboard")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showAddJob = true }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showAddJob) {
                AddOrEditJobView(onSave: fetchJobs)
            }
            .onAppear {
                fetchJobs()
            }
        }
    }

    func fetchJobs() {
        isLoading = true
        Firestore.firestore().collection("jobs").getDocuments { snapshot, error in
            if let docs = snapshot?.documents {
                self.jobs = docs.compactMap { try? $0.data(as: JobPosting.self) }
            } else {
                print("❌ Failed to load jobs: \(error?.localizedDescription ?? "Unknown")")
            }
            isLoading = false
        }
    }
}