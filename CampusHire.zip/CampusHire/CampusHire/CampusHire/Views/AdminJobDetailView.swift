import SwiftUI
import FirebaseFirestore

struct AdminJobDetailView: View {
    @State var job: JobPosting
    @Environment(\.dismiss) var dismiss

    @State private var applicants: [ApplicantSummary] = []
    @State private var isLoadingApplicants = true
    @State private var isDriveEnded = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Group {
                    TextField("Job Title", text: $job.title)
                        .textFieldStyle(.roundedBorder)
                    TextField("Company", text: Binding(
                        get: { job.company ?? "" },
                        set: { job.company = $0 }))
                        .textFieldStyle(.roundedBorder)
                    TextField("Location", text: Binding(
                        get: { job.location ?? "" },
                        set: { job.location = $0 }))
                        .textFieldStyle(.roundedBorder)
                    TextField("Salary", text: Binding(
                        get: { job.salary ?? "" },
                        set: { job.salary = $0 }))
                        .textFieldStyle(.roundedBorder)
                    TextField("Deadline", text: Binding(
                        get: { job.applicationDeadline ?? "" },
                        set: { job.applicationDeadline = $0 }))
                        .textFieldStyle(.roundedBorder)
                    TextField("Test Date", text: Binding(
                        get: { job.onlineTestDate ?? "" },
                        set: { job.onlineTestDate = $0 }))
                        .textFieldStyle(.roundedBorder)
                    TextField("Interview Date", text: Binding(
                        get: { job.interviewDate ?? "" },
                        set: { job.interviewDate = $0 }))
                        .textFieldStyle(.roundedBorder)
                    TextField("Min GPA", text: Binding(
                        get: { job.minGPA ?? "" },
                        set: { job.minGPA = $0 }))
                        .textFieldStyle(.roundedBorder)
                    TextField("Eligible Branches (comma separated)", text: Binding(
                        get: { job.eligibleBranches?.joined(separator: ", ") ?? "" },
                        set: { job.eligibleBranches = $0.components(separatedBy: ",").map { $0.trimmingCharacters(in: .whitespaces) } }))
                        .textFieldStyle(.roundedBorder)
                }

                Text("Description")
                TextEditor(text: Binding(
                    get: { job.description ?? "" },
                    set: { job.description = $0 }))
                    .frame(height: 120)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.4)))

                Toggle("Urgent", isOn: Binding(
                    get: { job.isUrgent ?? false },
                    set: { job.isUrgent = $0 }))

                Button("Save Changes") {
                    saveJobEdits()
                }
                .buttonStyle(.borderedProminent)

                Divider()
                if isDriveEnded {
                    Label("This job drive has ended.", systemImage: "xmark.seal.fill")
                        .foregroundColor(.red)
                } else {
                    Button("End Job Drive") {
                        endJobDrive()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                }

                Divider()
                Text("Applicants")
                    .font(.title3).bold()

                if isLoadingApplicants {
                    ProgressView("Loading applicants...")
                } else if applicants.isEmpty {
                    Text("No applicants yet.")
                        .foregroundColor(.gray)
                } else {
                    ForEach(applicants) { applicant in
                        NavigationLink(destination: ApplicantDetailView(userId: applicant.uid)) {
                            Text(applicant.name)
                        }
                        .padding(.vertical, 4)
                    }
                }

                Spacer()
            }
            .padding()
        }
        .navigationTitle("Edit Job")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            fetchApplicants()
        }
    }

    func saveJobEdits() {
        guard let docId = job.id else { return }
        var updatedData: [String: Any] = [
            "title": job.title,
            "company": job.company ?? "",
            "location": job.location ?? "",
            "salary": job.salary ?? "",
            "applicationDeadline": job.applicationDeadline ?? "",
            "onlineTestDate": job.onlineTestDate ?? "",
            "interviewDate": job.interviewDate ?? "",
            "description": job.description ?? "",
            "isUrgent": job.isUrgent ?? false,
            "minGPA": job.minGPA ?? "",
            "eligibleBranches": job.eligibleBranches ?? []
        ]

        Firestore.firestore().collection("jobs").document(docId).updateData(updatedData) { error in
            if let error = error {
                print("❌ Failed to update job: \(error.localizedDescription)")
            }
        }
    }

    func endJobDrive() {
        guard let docId = job.id else {
            print("❌ job.id is nil — cannot end drive")
            return
        }

        Firestore.firestore().collection("jobs").document(docId).updateData(["isClosed": true]) { error in
            if let error = error {
                print("❌ Failed to end drive: \(error.localizedDescription)")
            } else {
                print("✅ Job drive ended successfully.")
                isDriveEnded = true
            }
        }
    }

    func fetchApplicants() {
        guard let jobName = job.company else {
            print("❌ No company name in job object")
            return
        }

        Firestore.firestore().collection("users").getDocuments { snapshot, _ in
            let allUsers = snapshot?.documents ?? []
            var result: [ApplicantSummary] = []
            let group = DispatchGroup()

            for user in allUsers {
                let uid = user.documentID
                group.enter()
                Firestore.firestore().collection("users").document(uid).collection("applications")
                    .whereField("companyName", isEqualTo: jobName)
                    .getDocuments { apps, _ in
                        if let hasApp = apps?.documents, !hasApp.isEmpty {
                            let name = user.data()["fullName"] as? String ?? user.data()["email"] as? String ?? uid
                            result.append(ApplicantSummary(uid: uid, name: name))
                        }
                        group.leave()
                    }
            }

            group.notify(queue: .main) {
                self.applicants = result
                self.isLoadingApplicants = false
            }
        }
    }
}

struct ApplicantSummary: Identifiable {
    let uid: String
    let name: String
    var id: String { uid }
}
