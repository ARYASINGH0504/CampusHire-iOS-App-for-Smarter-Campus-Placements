//
//  AdminProfileView.swift
//  CampusHire
//
//  Created by lokesh sagi on 12/05/25.
//


import SwiftUI
import FirebaseAuth

struct AdminProfileView: View {
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack(spacing: 20) {
            Text("Admin Settings")
                .font(.title2).bold()

            Button("Log Out") {
                try? Auth.auth().signOut()
            }
            .foregroundColor(.red)
            .padding()
            .background(Color.gray.opacity(0.2))
            .cornerRadius(10)

            Spacer()
        }
        .padding()
    }
}