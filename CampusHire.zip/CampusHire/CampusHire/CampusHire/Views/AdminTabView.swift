//
//  AdminTabView.swift
//  CampusHire
//
//  Created by lokesh sagi on 12/05/25.
//


import SwiftUI
import FirebaseAuth

struct AdminTabView: View {
    @State private var selection = 0

    var body: some View {
        TabView(selection: $selection) {
            AdminDashboardView()
                .tabItem {
                    Label("Jobs", systemImage: "list.bullet.rectangle")
                }
                .tag(0)

            AdminProfileView()
                .tabItem {
                    Label("Admin", systemImage: "person.crop.circle")
                }
                .tag(1)
        }
    }
}