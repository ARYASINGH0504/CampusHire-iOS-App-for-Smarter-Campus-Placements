import SwiftUI
import FirebaseFirestore
import FirebaseStorage

struct ApplicantDetailView: View {
    let userId: String
    @State private var fullName = ""
    @State private var email = ""
    @State private var cgpa = ""
    @State private var branch = ""
    @State private var skills = ""
    @State private var roles = ""
    @State private var resumeURL: URL? = nil
    @State private var isLoading = true

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if isLoading {
                    ProgressView("Loading applicant info...")
                } else {
                    Group {
                        labeledRow(label: "Name", value: fullName)
                        labeledRow(label: "Email", value: email)
                        labeledRow(label: "CGPA", value: cgpa)
                        labeledRow(label: "Branch", value: branch)
                        labeledRow(label: "Skills", value: skills)
                        labeledRow(label: "Preferred Roles", value: roles)
                    }

                    if let url = resumeURL {
                        NavigationLink("View Resume") {
                            PDFViewer(url: url)
                        }
                        .buttonStyle(.borderedProminent)
                        .padding(.top)
                    } else {
                        Text("No resume found.")
                            .foregroundColor(.gray)
                            .padding(.top)
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Applicant Details")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            fetchApplicantInfo()
        }
    }

    @ViewBuilder
    func labeledRow(label: String, value: String) -> some View {
        HStack(alignment: .top) {
            Text("\(label):")
                .bold()
                .frame(width: 130, alignment: .leading)
            Text(value)
                .multilineTextAlignment(.leading)
        }
    }

    func fetchApplicantInfo() {
        let db = Firestore.firestore().collection("users").document(userId)
        db.getDocument { snapshot, error in
            guard let data = snapshot?.data(), error == nil else {
                print("❌ Error fetching applicant info: \(error?.localizedDescription ?? "Unknown")")
                isLoading = false
                return
            }
            self.fullName = data["fullName"] as? String ?? ""
            self.email = data["email"] as? String ?? ""
            self.cgpa = data["cgpa"] as? String ?? ""
            self.branch = data["branch"] as? String ?? ""
            self.skills = data["skills"] as? String ?? ""
            self.roles = data["preferredRoles"] as? String ?? ""
            fetchResume()
        }
    }

    func fetchResume() {
        let ref = Storage.storage().reference().child("resumes/\(userId).pdf")
        ref.downloadURL { url, error in
            if let url = url {
                self.resumeURL = url
            } else {
                print("❌ Resume not found: \(error?.localizedDescription ?? "Unknown")")
            }
            self.isLoading = false
        }
    }
}
