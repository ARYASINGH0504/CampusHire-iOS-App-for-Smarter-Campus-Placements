import SwiftUI
import FirebaseFirestore
import FirebaseAuth
import MapKit
import EventKit
import UserNotifications

struct CompanyDetailView: View {
    let job: JobPosting
    @State private var hasApplied = false
    @State private var showSuccess = false
    @State private var savedJobs: Set<String> = []

    @State private var reminderScheduledForTest = false
    @State private var reminderScheduledForInterview = false
    @State private var calendarAddedForTest = false
    @State private var calendarAddedForInterview = false
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text(job.company ?? "-")
                    .font(.largeTitle).bold()

                Text(job.title)
                    .font(.title2).foregroundColor(.secondary)

                if let loc = job.location {
                    Label(loc, systemImage: "mappin.and.ellipse")
                        .font(.subheadline).foregroundColor(.gray)
                }
                if let sal = job.salary {
                    Label(sal, systemImage: "dollarsign.circle")
                        .font(.subheadline).foregroundColor(.gray)
                }

                Divider()
                Text("Important Dates").font(.title3).bold()

                if let test = job.onlineTestDate {
                    dateRow(label: "Online Test", date: test, icon: "pencil.and.outline", color: .blue)
                    if !calendarAddedForTest && !hasApplied {
                        Button("📅 Add Test to Calendar & Reminder") {
                            addEventToCalendar(dateString: test, title: "Online Test - \(job.company ?? "-")") {
                                calendarAddedForTest = true
                                syncCalendarStatus(field: "calendarAddedForTest", value: true)
                                showAlertWith("Test added to calendar.")
                            }
                            scheduleReminder(dateString: test, title: "Online Test - \(job.company ?? "-")") {
                                reminderScheduledForTest = true
                                syncCalendarStatus(field: "reminderScheduledForTest", value: true)
                                showAlertWith("Test reminder scheduled.")
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    } else if calendarAddedForTest {
                        Label("📅 Test added to calendar", systemImage: "checkmark.circle.fill")
                            .foregroundColor(.green)
                    }
                }

                if let interview = job.interviewDate {
                    dateRow(label: "Interview", date: interview, icon: "person.2.fill", color: .green)
                    if !calendarAddedForInterview && !hasApplied {
                        Button("📅 Add Interview to Calendar & Reminder") {
                            addEventToCalendar(dateString: interview, title: "Interview - \(job.company ?? "-")") {
                                calendarAddedForInterview = true
                                syncCalendarStatus(field: "calendarAddedForInterview", value: true)
                                showAlertWith("Interview added to calendar.")
                            }
                            scheduleReminder(dateString: interview, title: "Interview - \(job.company ?? "-")") {
                                reminderScheduledForInterview = true
                                syncCalendarStatus(field: "reminderScheduledForInterview", value: true)
                                showAlertWith("Interview reminder scheduled.")
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    } else if calendarAddedForInterview {
                        Label("📅 Interview added to calendar", systemImage: "checkmark.circle.fill")
                            .foregroundColor(.green)
                    }
                }

                if let deadline = job.applicationDeadline {
                    dateRow(label: "Deadline", date: deadline, icon: "clock", color: .red)
                }

                Divider()
                Text("Job Description").font(.title3).bold()
                Text(job.description ?? "-").font(.body).padding(.top, 5)

                if !hasApplied {
                    Button {
                        applyNow()
                    } label: {
                        Text("Apply Now")
                            .frame(maxWidth: .infinity).padding()
                            .background(Color.blue).foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding(.top, 30)
                } else {
                    Label("You have already applied!", systemImage: "checkmark.seal.fill")
                        .foregroundColor(.green).font(.headline)
                        .padding(.top, 30)
                }
            }
            .padding()
        }
        .navigationTitle("Job Details")
        .navigationBarTitleDisplayMode(.inline)
        .alert(alertMessage, isPresented: $showAlert) {
            Button("OK", role: .cancel) {}
        }
        .onAppear {
            checkIfAlreadyApplied()
            fetchSavedJobs()
            fetchCalendarStatus()
        }
    }

    // MARK: - Calendar Logic

    func getOrCreateCalendar(completion: @escaping (EKCalendar?) -> Void) {
        let store = EKEventStore()
        store.requestAccess(to: .event) { granted, _ in
            guard granted else { completion(nil); return }
            if let existing = store.calendars(for: .event).first(where: { $0.title == "CampusHire" }) {
                completion(existing)
            } else {
                let newCal = EKCalendar(for: .event, eventStore: store)
                newCal.title = "CampusHire"
                newCal.source = store.defaultCalendarForNewEvents?.source
                do {
                    try store.saveCalendar(newCal, commit: true)
                    completion(newCal)
                } catch {
                    print("❌ Calendar creation error: \(error)")
                    completion(nil)
                }
            }
        }
    }

    func addEventToCalendar(dateString: String, title: String, completion: @escaping () -> Void) {
        getOrCreateCalendar { calendar in
            guard let calendar = calendar else { return }
            let store = EKEventStore()
            let formatter = DateFormatter(); formatter.dateFormat = "MMM d, yyyy"
            guard let date = formatter.date(from: dateString) else { return }
            let event = EKEvent(eventStore: store)
            event.title = title
            event.startDate = date
            event.endDate = date.addingTimeInterval(3600)
            event.calendar = calendar
            do {
                try store.save(event, span: .thisEvent)
                DispatchQueue.main.async { completion() }
            } catch {
                print("❌ Save error: \(error)")
            }
        }
    }

    func scheduleReminder(dateString: String, title: String, completion: @escaping () -> Void) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { granted, _ in
            guard granted else { return }
            let formatter = DateFormatter(); formatter.dateFormat = "MMM d, yyyy"
            guard let eventDate = formatter.date(from: dateString),
                  let reminderDate = Calendar.current.date(byAdding: .hour, value: -24, to: eventDate),
                  reminderDate > Date() else { return }
            let content = UNMutableNotificationContent()
            content.title = "Reminder: \(title)"
            content.body = "You have an upcoming event tomorrow."
            content.sound = .default
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: reminderDate.timeIntervalSinceNow, repeats: false)
            let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
            UNUserNotificationCenter.current().add(request)
            DispatchQueue.main.async { completion() }
        }
    }

    func syncCalendarStatus(field: String, value: Bool) {
        guard let uid = Auth.auth().currentUser?.uid,
              let jobName = job.company else { return }
        let query = Firestore.firestore().collection("users").document(uid).collection("applications").whereField("companyName", isEqualTo: jobName)
        query.getDocuments { snapshot, _ in
            guard let doc = snapshot?.documents.first else { return }
            doc.reference.updateData([field: value])
        }
    }

    func fetchCalendarStatus() {
        guard let uid = Auth.auth().currentUser?.uid,
              let jobName = job.company else { return }
        let query = Firestore.firestore().collection("users").document(uid).collection("applications").whereField("companyName", isEqualTo: jobName)
        query.getDocuments { snapshot, _ in
            if let data = snapshot?.documents.first?.data() {
                calendarAddedForTest = data["calendarAddedForTest"] as? Bool ?? false
                reminderScheduledForTest = data["reminderScheduledForTest"] as? Bool ?? false
                calendarAddedForInterview = data["calendarAddedForInterview"] as? Bool ?? false
                reminderScheduledForInterview = data["reminderScheduledForInterview"] as? Bool ?? false
            }
        }
    }

    func showAlertWith(_ message: String) {
        alertMessage = message
        showAlert = true
    }

    @ViewBuilder
    private func dateRow(label: String, date: String, icon: String, color: Color) -> some View {
        HStack {
            Image(systemName: icon).foregroundColor(color)
            Text("\(label): \(date)")
                .font(.subheadline)
                .foregroundColor(.primary)
        }
    }

    private func applyNow() {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        let data: [String:Any] = [
            "companyName": job.company ?? "-",
            "appliedDate": DateFormatter.localizedString(from: Date(), dateStyle: .medium, timeStyle: .none),
            "onlineTestDate": job.onlineTestDate ?? "",
            "interviewDate": job.interviewDate ?? "",
            "applicationDeadline": job.applicationDeadline ?? ""
        ]
        Firestore.firestore().collection("users").document(uid).collection("applications").addDocument(data: data) { err in
            if err == nil { hasApplied = true; showSuccess = true }
        }
    }

    private func checkIfAlreadyApplied() {
        guard let uid = Auth.auth().currentUser?.uid,
              let name = job.company else { return }
        Firestore.firestore().collection("users").document(uid).collection("applications").whereField("companyName", isEqualTo: name).getDocuments { snap, _ in
            if let docs = snap?.documents, !docs.isEmpty {
                hasApplied = true
            }
        }
    }

    private func fetchSavedJobs() {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        Firestore.firestore().collection("users").document(uid).collection("savedJobs").getDocuments { snap, _ in
            if let docs = snap?.documents {
                savedJobs = Set(docs.map { $0.documentID })
            }
        }
    }
}
