//
//  RootView.swift
//  CampusHire
//
//  Created by lokesh sagi on 12/05/25.
//


import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct RootView: View {
    @State private var isAdmin: Bool? = nil
    @State private var isLoading = true

    var body: some View {
        Group {
            if isLoading {
                ProgressView("Checking user role...")
            } else if isAdmin == true {
                AdminTabView()
            } else {
                MainTabView()
            }
        }
        .onAppear(perform: checkUserRole)
    }

    func checkUserRole() {
        guard let uid = Auth.auth().currentUser?.uid else {
            self.isAdmin = false
            self.isLoading = false
            return
        }

        Firestore.firestore().collection("users").document(uid).getDocument { doc, error in
            if let data = doc?.data() {
                self.isAdmin = data["isAdmin"] as? Bool ?? false
            } else {
                self.isAdmin = false
            }
            self.isLoading = false
        }
    }
}
